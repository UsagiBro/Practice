package ua.nure.your_last_name.Practice6.part3;

public class Part3 {
	
	public static void main(String[] args) {
		
	}

}
