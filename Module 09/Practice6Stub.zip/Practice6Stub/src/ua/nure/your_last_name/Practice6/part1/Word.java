package ua.nure.your_last_name.Practice6.part1;

public class Word {
	
	private String word;
	
	private int frequency;

	public Word(String word) {
		this.word = word;
		frequency = 1;
	}

}
