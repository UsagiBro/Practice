package ua.nure.your_last_name.Practice6.part4;

public class Graph {

}
