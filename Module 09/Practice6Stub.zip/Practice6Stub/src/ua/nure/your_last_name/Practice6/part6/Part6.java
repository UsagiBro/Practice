package ua.nure.your_last_name.Practice6.part6;

public class Part6 {
	
	public static void main(String[] args) {
	}

}
