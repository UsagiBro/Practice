package ua.nure.your_last_name.Practice6.part2;

public class Part2 {
	
	public static void main(String[] args) {
		
	}

}
