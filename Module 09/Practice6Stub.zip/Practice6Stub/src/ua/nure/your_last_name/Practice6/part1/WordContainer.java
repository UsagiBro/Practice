package ua.nure.your_last_name.Practice6.part1;

// you can extend this class from one of the core container
// or aggregate it inside of class 
public class WordContainer {  

}
