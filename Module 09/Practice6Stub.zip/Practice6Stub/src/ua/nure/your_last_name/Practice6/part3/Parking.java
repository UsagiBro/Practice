package ua.nure.your_last_name.Practice6.part3;

public class Parking {

}
