package ua.nure.your_last_name.Practice6.part7;

public class Part7 {
	
	public static void main(String[] args) {
	}

}
