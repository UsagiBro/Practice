package ua.nure.your_last_name.Practice6.part5;

public class Tree<E extends Comparable<E>> {
	
	private static final String INDENT = "   ";

	private Node<E> root = null;
	
	public boolean remove(E element) {		
		return false;
	}
	
	public void add(E[] elements) {
	}
	
	public boolean add(E e) {
		return false;
	}	

	public void print() {
		
	}
	
	private static class Node<E> {
		
	}	

}
