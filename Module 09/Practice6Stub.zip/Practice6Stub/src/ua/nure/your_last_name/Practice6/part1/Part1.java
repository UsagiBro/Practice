package ua.nure.your_last_name.Practice6.part1;

public class Part1 {

	public static void main(String[] args) {
	}

}
