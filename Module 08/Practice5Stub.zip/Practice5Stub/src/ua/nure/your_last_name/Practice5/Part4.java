package ua.nure.your_last_name.Practice5;

public class Part4 {
	
	public static void main(String[] args) {
		
	}

}
