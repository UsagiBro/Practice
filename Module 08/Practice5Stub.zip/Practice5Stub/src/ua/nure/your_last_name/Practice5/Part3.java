package ua.nure.your_last_name.Practice5;

public class Part3 {

	public static void main(String[] args) {

	}

}
